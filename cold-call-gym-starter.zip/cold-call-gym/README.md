# Cold Call Gym

Voice-first AI sales practice SaaS.

## Core loop
Choose scenario → call AI prospect → handle objections → end call → receive coaching → practice again.

## MVP
- Authentication
- Scenario/persona library
- Phone-like voice UI
- Gemini Live voice integration
- Server-side daily free allowance
- Paid credits
- Stripe checkout/webhooks
- Call history
- Post-call coaching
- Supabase database
- CI/CD

## Architecture
- `apps/web`: Next.js + TypeScript
- `services/voice-gateway`: Fastify + WebSocket voice relay
- `packages/shared`: shared types
- `supabase`: migrations and seed data
- `docs`: product and engineering docs

Recommended deployment:
- Web: Vercel
- Voice gateway: Render or Cloud Run
- Auth/DB: Supabase
- Payments: Stripe

## Important
The starter uses a mock voice provider by default. The Gemini Live provider is deliberately isolated behind an interface and should be implemented against the current official Gemini Live API in Phase 4.

Suggested env-configurable model:
`GEMINI_LIVE_MODEL=gemini-3.8-live`

## Start
```bash
pnpm install
cp apps/web/.env.example apps/web/.env.local
cp services/voice-gateway/.env.example services/voice-gateway/.env
pnpm dev:web
pnpm dev:gateway
```

Read `CLAUDE.md` and `docs/CLAUDE_CODE_PLAN.md` before building with Claude Code.
