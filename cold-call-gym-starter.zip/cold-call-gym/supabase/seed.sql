insert into public.scenarios(slug,name,description,difficulty,objective,prospect_role,prospect_company,persona,hidden_state,target_duration_seconds)
values
('busy-vp','Busy VP of Sales','Earn attention from an impatient executive.','realistic','Secure permission for a deeper conversation.','VP of Sales','Northstar Software','{"patience":"low","skepticism":"high"}','{"pain_point":"forecast visibility","opening_objection":"I have two minutes. What is this about?"}',180),
('send-email','Send me an email','Recover from the classic brush-off.','practice','Earn one discovery question or follow-up.','Director of Operations','Lumen Logistics','{"patience":"medium","skepticism":"medium"}','{"pain_point":"manual reporting","opening_objection":"Can you just email me something?"}',300),
('competitor','We already use a competitor','Differentiate without attacking the incumbent.','challenge','Uncover one unmet need.','Head of Revenue Operations','Atlas Cloud','{"patience":"medium","skepticism":"high"}','{"pain_point":"adoption","opening_objection":"We already have a platform for that."}',360)
on conflict(slug) do nothing;
