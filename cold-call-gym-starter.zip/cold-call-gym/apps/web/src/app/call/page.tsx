"use client";
import {useEffect,useState} from "react";
export default function Call(){const[s,setS]=useState(0);const[a,setA]=useState(false);useEffect(()=>{if(!a)return;const id=setInterval(()=>setS(v=>v+1),1000);return()=>clearInterval(id)},[a]);
const t=`${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;
return <div className="call card"><p className="accent"><b>REALISTIC MODE</b></p><div className="avatar">VP</div><h1>Jordan Blake</h1><p className="muted">VP of Sales · Northstar Software</p><div className="timer">{t}</div><p>{!a?<button className="button" onClick={()=>setA(true)}>Start mock call</button>:<a className="button" href="/report/demo">End call</a>}</p><p className="muted">Starter mode uses a mock voice provider. Gemini Live is Phase 4.</p></div>}
