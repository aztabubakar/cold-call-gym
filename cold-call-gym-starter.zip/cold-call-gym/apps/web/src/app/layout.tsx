import "./globals.css";
import type { ReactNode } from "react";
export const metadata={title:"Cold Call Gym",description:"Practice cold calls with realistic AI prospects."};
export default function Layout({children}:{children:ReactNode}){return <html lang="en"><body><main className="container">
<nav className="nav"><a className="brand" href="/">Cold Call <span className="accent">Gym</span></a><div style={{display:"flex",gap:14}}><a href="/scenarios">Scenarios</a><a href="/billing">Credits</a></div></nav>{children}
</main></body></html>}
