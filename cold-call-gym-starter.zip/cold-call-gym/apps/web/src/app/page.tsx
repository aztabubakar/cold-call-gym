export default function Home(){return <>
<section className="hero"><p className="accent"><b>VOICE-FIRST SALES PRACTICE</b></p><h1>Get your reps in<br/>before the real call.</h1><p className="muted" style={{fontSize:20,maxWidth:720}}>Practice cold calls against realistic AI prospects, handle objections live, and get evidence-based coaching.</p><p><a className="button" href="/scenarios">Start a practice call</a></p></section>
<section className="grid"><div className="card"><div className="metric">10 min</div><div className="muted">Free every day</div></div><div className="card"><div className="metric">24</div><div className="muted">Practice credits</div></div><div className="card"><div className="metric">3</div><div className="muted">Calls this week</div></div></section>
</>}
