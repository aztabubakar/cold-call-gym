const items=[
["Busy VP of Sales","Realistic","Earn attention from an impatient executive."],
["Send me an email","Practice","Recover from the classic brush-off."],
["We already use a competitor","Challenge","Differentiate without attacking the incumbent."],
["Not interested","Realistic","Handle early resistance naturally."],
["Gatekeeper","Challenge","Reach the right person professionally."]
];
export default function Scenarios(){return <><h1>Choose your drill</h1><p className="muted">Every prospect has different patience, objections, and hidden needs.</p><div className="grid">{items.map(([n,d,x])=><div className="card" key={n}><div className="accent"><b>{d}</b></div><h3>{n}</h3><p className="muted">{x}</p><a className="button" href="/call">Call prospect</a></div>)}</div></>}
