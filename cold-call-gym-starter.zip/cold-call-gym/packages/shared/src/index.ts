import { z } from "zod";

export const DifficultySchema = z.enum(["practice","realistic","challenge"]);
export const CallStateSchema = z.enum(["created","authorized","connecting","active","ending","completed","failed"]);

export const CoachingReportSchema = z.object({
  overallSummary: z.string(),
  categories: z.array(z.object({
    name: z.string(),
    score: z.number().min(0).max(100),
    evidence: z.array(z.string()),
    feedback: z.string(),
  })),
  strengths: z.array(z.string()),
  improvements: z.array(z.string()),
  nextDrill: z.string(),
});
